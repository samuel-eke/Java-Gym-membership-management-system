package com.example.gymmanagment;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DashboardUI extends Application {
    private Label lblTotalMembers;
    private Label lblActiveSubscriptions;
    private TableView<Payment> tblRecentPayments;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Gym Dashboard");

        lblTotalMembers = new Label("Total Members: Loading...");
        lblActiveSubscriptions = new Label("Active Subscriptions: Loading...");

        tblRecentPayments = new TableView<>();
        TableColumn<Payment, Integer> colPaymentID = new TableColumn<>("Payment ID");
        colPaymentID.setCellValueFactory(new PropertyValueFactory<>("paymentId"));

        TableColumn<Payment, Integer> colMemberID = new TableColumn<>("Member ID");
        colMemberID.setCellValueFactory(new PropertyValueFactory<>("memberId"));

        TableColumn<Payment, Double> colAmount = new TableColumn<>("Amount Paid");
        colAmount.setCellValueFactory(new PropertyValueFactory<>("amountPaid"));

        TableColumn<Payment, String> colDate = new TableColumn<>("Payment Date");
        colDate.setCellValueFactory(new PropertyValueFactory<>("paymentDate"));

        tblRecentPayments.getColumns().addAll(colPaymentID, colMemberID, colAmount, colDate);

        VBox vbox = new VBox(10, lblTotalMembers, lblActiveSubscriptions, tblRecentPayments);
        vbox.setPadding(new Insets(20));

        fetchDashboardData();

        primaryStage.setScene(new Scene(vbox, 600, 400));
        primaryStage.show();
    }

    private void fetchDashboardData() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            // Fetch total members
            String totalMembersQuery = "SELECT COUNT(*) FROM members";
            try (PreparedStatement stmt = conn.prepareStatement(totalMembersQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    lblTotalMembers.setText("Total Members: " + rs.getInt(1));
                }
            }

            // Fetch active subscriptions
            String activeSubsQuery = "SELECT COUNT(DISTINCT member_id) FROM subscriptions WHERE end_date >= CURDATE()";
            try (PreparedStatement stmt = conn.prepareStatement(activeSubsQuery);
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    lblActiveSubscriptions.setText("Active Subscriptions: " + rs.getInt(1));
                }
            }

            // Fetch recent payments
            String recentPaymentsQuery = "SELECT * FROM payments ORDER BY payment_date DESC LIMIT 5";
            try (PreparedStatement stmt = conn.prepareStatement(recentPaymentsQuery);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    tblRecentPayments.getItems().add(new Payment(
                            rs.getInt("payment_id"),
                            rs.getInt("member_id"),
                            rs.getDouble("amount_paid"),
                            rs.getString("payment_date")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static class Payment {
        private final int paymentId;
        private final int memberId;
        private final double amountPaid;
        private final String paymentDate;

        public Payment(int paymentId, int memberId, double amountPaid, String paymentDate) {
            this.paymentId = paymentId;
            this.memberId = memberId;
            this.amountPaid = amountPaid;
            this.paymentDate = paymentDate;
        }

        public int getPaymentId() { return paymentId; }
        public int getMemberId() { return memberId; }
        public double getAmountPaid() { return amountPaid; }
        public String getPaymentDate() { return paymentDate; }
    }
}
