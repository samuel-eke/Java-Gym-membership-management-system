package com.example.gymmanagment;



import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MemberUI extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Manage Members");

        // Input fields
        TextField firstNameField = new TextField();
        firstNameField.setPromptText("First Name");

        TextField lastNameField = new TextField();
        lastNameField.setPromptText("Last Name");

        TextField phoneField = new TextField();
        phoneField.setPromptText("Phone Number");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        DatePicker joinDatePicker = new DatePicker();

        Button addButton = new Button("Add Member");
        addButton.setOnAction(e -> addMember(
                firstNameField.getText(),
                lastNameField.getText(),
                phoneField.getText(),
                emailField.getText(),
                joinDatePicker.getValue().toString()
        ));

        VBox layout = new VBox(10, firstNameField, lastNameField, phoneField, emailField, joinDatePicker, addButton);
        layout.setPadding(new Insets(20));

        primaryStage.setScene(new Scene(layout, 300, 300));
        primaryStage.show();
    }

    private void addMember(String firstName, String lastName, String phone, String email, String joinDate) {
        String sql = "INSERT INTO members (Firstname, Lastname, phone, email, join_date) VALUES (?, ?, ?, ?, ?)";

        Connection conn = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establish connection
            conn = DatabaseConnection.getConnection();
            if (conn != null) {
                preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, firstName);
                preparedStatement.setString(2, lastName);
                preparedStatement.setString(3, phone);
                preparedStatement.setString(4, email);
                preparedStatement.setString(5, joinDate);

                int rowsInserted = preparedStatement.executeUpdate();
                if (rowsInserted > 0) {
                    showAlert("Success", "Member added successfully!");
                } else {
                    showAlert("Error", "No member was added.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to add member: " + e.getMessage());
        } finally {
            // Close resources
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
