package com.example.gymmanagment;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddMemberUI extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Add Member");

        // Form elements
        Label lblFirstName = new Label("First Name:");
        TextField txtFirstName = new TextField();

        Label lblLastName = new Label("Last Name:");
        TextField txtLastName = new TextField();

        Label lblPhone = new Label("Phone:");
        TextField txtPhone = new TextField();

        Label lblEmail = new Label("Email:");
        TextField txtEmail = new TextField();

        Label lblJoinDate = new Label("Join Date (YYYY-MM-DD):");
        TextField txtJoinDate = new TextField();

        Label lblSubscription = new Label("Subscription Plan:");
        ComboBox<String> cbSubscription = new ComboBox<>();
        cbSubscription.getItems().addAll("Monthly", "Quarterly", "Yearly");
        cbSubscription.setValue("Monthly");

        Button btnAdd = new Button("Add Member");
        Label lblStatus = new Label();

        // Add button action
        btnAdd.setOnAction(e -> {
            String firstName = txtFirstName.getText().trim();
            String lastName = txtLastName.getText().trim();
            String phone = txtPhone.getText().trim();
            String email = txtEmail.getText().trim();
            String joinDate = txtJoinDate.getText().trim();
            String subscriptionPlan = cbSubscription.getValue();
            int price = getPlanPrice(subscriptionPlan);

            if (!firstName.isEmpty() && !lastName.isEmpty() && !phone.isEmpty() && !email.isEmpty() && !joinDate.isEmpty()) {
                addMember(firstName, lastName, phone, email, joinDate, subscriptionPlan, price, lblStatus);
            } else {
                lblStatus.setText("Please fill all fields.");
            }
        });

        // Layout setup
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        gridPane.add(lblFirstName, 0, 0);
        gridPane.add(txtFirstName, 1, 0);
        gridPane.add(lblLastName, 0, 1);
        gridPane.add(txtLastName, 1, 1);
        gridPane.add(lblPhone, 0, 2);
        gridPane.add(txtPhone, 1, 2);
        gridPane.add(lblEmail, 0, 3);
        gridPane.add(txtEmail, 1, 3);
        gridPane.add(lblJoinDate, 0, 4);
        gridPane.add(txtJoinDate, 1, 4);
        gridPane.add(lblSubscription, 0, 5);
        gridPane.add(cbSubscription, 1, 5);
        gridPane.add(btnAdd, 1, 6);
        gridPane.add(lblStatus, 1, 7);

        primaryStage.setScene(new Scene(gridPane, 400, 350));
        primaryStage.show();
    }

    private int getPlanPrice(String plan) {
        return switch (plan) {
            case "Monthly" -> 50;
            case "Quarterly" -> 130;
            case "Yearly" -> 500;
            default -> 0;
        };
    }

    private void addMember(String firstName, String lastName, String phone, String email, String joinDate, String planName, int price, Label statusLabel) {
        String insertMemberSQL = "INSERT INTO members (Firstname, Lastname, phone, email, join_date) VALUES (?, ?, ?, ?, ?)";
        String insertSubscriptionSQL = "INSERT INTO subscriptions (member_id, plan_name, start_date, end_date, price) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement memberStmt = conn.prepareStatement(insertMemberSQL, PreparedStatement.RETURN_GENERATED_KEYS)) {

            memberStmt.setString(1, firstName);
            memberStmt.setString(2, lastName);
            memberStmt.setString(3, phone);
            memberStmt.setString(4, email);
            memberStmt.setString(5, joinDate);
            int rowsAffected = memberStmt.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet generatedKeys = memberStmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int memberId = generatedKeys.getInt(1);
                    try (PreparedStatement subscriptionStmt = conn.prepareStatement(insertSubscriptionSQL)) {
                        subscriptionStmt.setInt(1, memberId);
                        subscriptionStmt.setString(2, planName);
                        subscriptionStmt.setString(3, joinDate);
                        subscriptionStmt.setString(4, "2025-12-31"); // Placeholder for end date logic
                        subscriptionStmt.setInt(5, price);
                        subscriptionStmt.executeUpdate();
                    }
                    statusLabel.setText("Member added with subscription!");
                }
            } else {
                statusLabel.setText("Failed to add member.");
            }
        } catch (SQLException e) {
            statusLabel.setText("Error adding member.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
