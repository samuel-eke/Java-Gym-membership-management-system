package com.example.gymmanagment;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewMembersUI extends Application {

    private TableView<Member> tableView;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("View Members");

        // TableView setup
        tableView = new TableView<>();
        TableColumn<Member, String> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getMemberId()));

        TableColumn<Member, String> firstNameColumn = new TableColumn<>("First Name");
        firstNameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getFirstName()));

        TableColumn<Member, String> lastNameColumn = new TableColumn<>("Last Name");
        lastNameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getLastName()));

        TableColumn<Member, String> phoneColumn = new TableColumn<>("Phone");
        phoneColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPhone()));

        TableColumn<Member, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getEmail()));

        TableColumn<Member, String> joinDateColumn = new TableColumn<>("Join Date");
        joinDateColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getJoinDate()));

        TableColumn<Member, String> subscriptionColumn = new TableColumn<>("Subscription Plan");
        subscriptionColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getSubscriptionPlan()));

        tableView.getColumns().addAll(idColumn, firstNameColumn, lastNameColumn, phoneColumn, emailColumn, joinDateColumn, subscriptionColumn);

        // Load data into TableView
        loadMembers();

        // Refresh button
        Button refreshButton = new Button("Refresh");
        refreshButton.setOnAction(e -> loadMembers());

        // Layout
        VBox layout = new VBox(10, tableView, refreshButton);
        layout.setPadding(new Insets(20));

        primaryStage.setScene(new Scene(layout, 700, 400));
        primaryStage.show();
    }

    private void loadMembers() {
        ObservableList<Member> membersList = FXCollections.observableArrayList();
        String sql = "SELECT m.member_id, m.Firstname, m.Lastname, m.phone, m.email, m.join_date, s.plan_name " +
                "FROM members m LEFT JOIN subscriptions s ON m.member_id = s.member_id";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql);
             ResultSet rs = preparedStatement.executeQuery()) {

            while (rs.next()) {
                membersList.add(new Member(
                        String.valueOf(rs.getInt("member_id")),
                        rs.getString("Firstname"),
                        rs.getString("Lastname"),
                        String.valueOf(rs.getLong("phone")),
                        rs.getString("email"),
                        rs.getString("join_date"),
                        rs.getString("plan_name")
                ));
            }

            tableView.setItems(membersList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    // Member model class
    public static class Member {
        private final String memberId;
        private final String firstName;
        private final String lastName;
        private final String phone;
        private final String email;
        private final String joinDate;
        private final String subscriptionPlan;

        public Member(String memberId, String firstName, String lastName, String phone, String email, String joinDate, String subscriptionPlan) {
            this.memberId = memberId;
            this.firstName = firstName;
            this.lastName = lastName;
            this.phone = phone;
            this.email = email;
            this.joinDate = joinDate;
            this.subscriptionPlan = subscriptionPlan;
        }

        public String getMemberId() { return memberId; }
        public String getFirstName() { return firstName; }
        public String getLastName() { return lastName; }
        public String getPhone() { return phone; }
        public String getEmail() { return email; }
        public String getJoinDate() { return joinDate; }
        public String getSubscriptionPlan() { return subscriptionPlan; }
    }
}
