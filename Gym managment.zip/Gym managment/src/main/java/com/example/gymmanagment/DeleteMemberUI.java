package com.example.gymmanagment;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DeleteMemberUI extends Application {
    private TextField txtMemberID;
    private Label lblStatus;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Delete Member");

        txtMemberID = new TextField();
        txtMemberID.setPromptText("Enter Member ID");

        Button btnDelete = new Button("Delete Member");
        btnDelete.setOnAction(e -> deleteMember());

        lblStatus = new Label();

        VBox layout = new VBox(10, txtMemberID, btnDelete, lblStatus);
        layout.setPadding(new Insets(20));

        primaryStage.setScene(new Scene(layout, 300, 200));
        primaryStage.show();
    }

    private void deleteMember() {
        String memberId = txtMemberID.getText().trim();
        if (memberId.isEmpty()) {
            lblStatus.setText("Please enter a Member ID.");
            return;
        }

        String deleteSQL = "DELETE FROM members WHERE member_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(deleteSQL)) {

            pstmt.setInt(1, Integer.parseInt(memberId));
            int rowsDeleted = pstmt.executeUpdate();

            if (rowsDeleted > 0) {
                lblStatus.setText("Member deleted successfully.");
                checkAndResetAutoIncrement(conn);
            } else {
                lblStatus.setText("Member not found.");
            }

        } catch (SQLException | NumberFormatException e) {
            lblStatus.setText("Error deleting member.");
            e.printStackTrace();
        }
    }

    private void checkAndResetAutoIncrement(Connection conn) throws SQLException {
        String checkSQL = "SELECT COUNT(*) FROM members";
        String resetSQL = "ALTER TABLE members AUTO_INCREMENT = 1";

        try (PreparedStatement checkStmt = conn.prepareStatement(checkSQL);
             ResultSet rs = checkStmt.executeQuery()) {
            if (rs.next() && rs.getInt(1) == 0) {
                try (PreparedStatement resetStmt = conn.prepareStatement(resetSQL)) {
                    resetStmt.executeUpdate();
                }
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
