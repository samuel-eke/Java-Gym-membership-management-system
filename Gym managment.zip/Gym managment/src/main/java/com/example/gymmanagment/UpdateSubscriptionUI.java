package com.example.gymmanagment;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdateSubscriptionUI extends Application {
    private ComboBox<String> memberComboBox;
    private ComboBox<String> planComboBox;
    private Label lblCurrentPlan;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Update Subscription Plan");

        memberComboBox = new ComboBox<>();
        loadMembers();
        memberComboBox.setPromptText("Select Member");
        memberComboBox.setOnAction(e -> loadCurrentPlan());

        lblCurrentPlan = new Label("Current Plan: ");

        planComboBox = new ComboBox<>(FXCollections.observableArrayList("Monthly", "Quarterly", "Yearly"));
        planComboBox.setPromptText("Select New Plan");

        Button btnUpdate = new Button("Update Plan");
        btnUpdate.setOnAction(e -> updateSubscription());

        VBox layout = new VBox(10, memberComboBox, lblCurrentPlan, planComboBox, btnUpdate);
        layout.setPadding(new Insets(20));

        primaryStage.setScene(new Scene(layout, 400, 300));
        primaryStage.show();
    }

    private void loadMembers() {
        ObservableList<String> membersList = FXCollections.observableArrayList();
        String sql = "SELECT member_id, Firstname, Lastname FROM members";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql);
             ResultSet rs = preparedStatement.executeQuery()) {

            while (rs.next()) {
                String memberInfo = rs.getInt("member_id") + " - " + rs.getString("Firstname") + " " + rs.getString("Lastname");
                membersList.add(memberInfo);
            }
            memberComboBox.setItems(membersList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadCurrentPlan() {
        if (memberComboBox.getValue() == null) return;

        String memberId = memberComboBox.getValue().split(" - ")[0];
        String sql = "SELECT plan_name FROM subscriptions WHERE member_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setInt(1, Integer.parseInt(memberId));
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                lblCurrentPlan.setText("Current Plan: " + rs.getString("plan_name"));
            } else {
                lblCurrentPlan.setText("Current Plan: Not Found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateSubscription() {
        if (memberComboBox.getValue() == null || planComboBox.getValue() == null) return;

        String memberId = memberComboBox.getValue().split(" - ")[0];
        String newPlan = planComboBox.getValue();

        String sql = "UPDATE subscriptions SET plan_name = ? WHERE member_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, newPlan);
            preparedStatement.setInt(2, Integer.parseInt(memberId));

            int rowsUpdated = preparedStatement.executeUpdate();

            if (rowsUpdated > 0) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Subscription updated successfully!", ButtonType.OK);
                alert.showAndWait();
                loadCurrentPlan();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
