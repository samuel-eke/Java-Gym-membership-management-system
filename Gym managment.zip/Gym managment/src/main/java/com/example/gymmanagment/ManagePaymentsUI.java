package com.example.gymmanagment;

import com.example.gymmanagment.DatabaseConnection;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.beans.property.SimpleStringProperty;


public class ManagePaymentsUI extends Application {
    private TableView<Payment> tableView;
    private TextField txtMemberID;
    private ComboBox<String> cmbPlanType;
    private DatePicker dpPaymentDate;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Manage Payments");

        tableView = new TableView<>();
        TableColumn<Payment, String> idColumn = new TableColumn<>("Payment ID");
        idColumn.setCellValueFactory(data -> data.getValue().paymentIdProperty());

        TableColumn<Payment, String> memberIdColumn = new TableColumn<>("Member ID");
        memberIdColumn.setCellValueFactory(data -> data.getValue().memberIdProperty());

        TableColumn<Payment, String> amountColumn = new TableColumn<>("Amount Paid");
        amountColumn.setCellValueFactory(data -> data.getValue().amountPaidProperty());

        TableColumn<Payment, String> dateColumn = new TableColumn<>("Payment Date");
        dateColumn.setCellValueFactory(data -> data.getValue().paymentDateProperty());

        tableView.getColumns().addAll(idColumn, memberIdColumn, amountColumn, dateColumn);

        loadPayments();

        txtMemberID = new TextField();
        txtMemberID.setPromptText("Member ID");

        cmbPlanType = new ComboBox<>();
        cmbPlanType.getItems().addAll("Monthly", "Quarterly", "Yearly");
        cmbPlanType.setPromptText("Select Plan Type");

        dpPaymentDate = new DatePicker();

        Button btnAddPayment = new Button("Add Payment");
        btnAddPayment.setOnAction(e -> addPayment());

        VBox layout = new VBox(10, tableView, txtMemberID, cmbPlanType, dpPaymentDate, btnAddPayment);
        layout.setPadding(new Insets(20));

        primaryStage.setScene(new Scene(layout, 600, 400));
        primaryStage.show();
    }

    private void loadPayments() {
        ObservableList<Payment> paymentsList = FXCollections.observableArrayList();
        String sql = "SELECT * FROM payments";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql);
             ResultSet rs = preparedStatement.executeQuery()) {

            while (rs.next()) {
                paymentsList.add(new Payment(
                        String.valueOf(rs.getInt("payment_id")),
                        String.valueOf(rs.getInt("member_id")),
                        String.valueOf(rs.getInt("amount_paid")),
                        rs.getString("payment_date")
                ));
            }

            tableView.setItems(paymentsList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addPayment() {
        if (cmbPlanType.getValue() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please select a plan type.", ButtonType.OK);
            alert.showAndWait();
            return;
        }

        int amount = getPlanPrice(cmbPlanType.getValue());
        String sql = "INSERT INTO payments (member_id, amount_paid, payment_date) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setInt(1, Integer.parseInt(txtMemberID.getText()));
            preparedStatement.setInt(2, amount);
            preparedStatement.setString(3, dpPaymentDate.getValue().toString());

            int rowsInserted = preparedStatement.executeUpdate();

            if (rowsInserted > 0) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Payment added successfully!", ButtonType.OK);
                alert.showAndWait();
                loadPayments();
            }
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
        }
    }

    private int getPlanPrice(String planType) {
        switch (planType) {
            case "Monthly": return 50;
            case "Quarterly": return 140;
            case "Yearly": return 500;
            default: return 0;
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static class Payment {
        private final SimpleStringProperty paymentId;
        private final SimpleStringProperty memberId;
        private final SimpleStringProperty amountPaid;
        private final SimpleStringProperty paymentDate;

        public Payment(String paymentId, String memberId, String amountPaid, String paymentDate) {
            this.paymentId = new SimpleStringProperty(paymentId);
            this.memberId = new SimpleStringProperty(memberId);
            this.amountPaid = new SimpleStringProperty(amountPaid);
            this.paymentDate = new SimpleStringProperty(paymentDate);
        }

        public SimpleStringProperty paymentIdProperty() { return paymentId; }
        public SimpleStringProperty memberIdProperty() { return memberId; }
        public SimpleStringProperty amountPaidProperty() { return amountPaid; }
        public SimpleStringProperty paymentDateProperty() { return paymentDate; }
    }
}
