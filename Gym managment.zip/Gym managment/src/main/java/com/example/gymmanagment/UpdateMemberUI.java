package com.example.gymmanagment;


import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdateMemberUI extends Application {
    private TextField txtFirstName, txtLastName, txtPhone, txtEmail, txtJoinDate;
    private ComboBox<String> cbSubscriptionPlan;
    private TextField txtMemberID;
    private Label lblStatus;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Update Member");

        Label lblMemberID = new Label("Member ID:");
        txtMemberID = new TextField();
        Button btnLoad = new Button("Load Member");
        btnLoad.setOnAction(e -> loadMember());

        Label lblFirstName = new Label("First Name:");
        txtFirstName = new TextField();

        Label lblLastName = new Label("Last Name:");
        txtLastName = new TextField();

        Label lblPhone = new Label("Phone:");
        txtPhone = new TextField();

        Label lblEmail = new Label("Email:");
        txtEmail = new TextField();

        Label lblJoinDate = new Label("Join Date (YYYY-MM-DD):");
        txtJoinDate = new TextField();

        Label lblSubscriptionPlan = new Label("Subscription Plan:");
        cbSubscriptionPlan = new ComboBox<>(FXCollections.observableArrayList("Monthly", "Quarterly", "Yearly"));

        Button btnUpdate = new Button("Update Member");
        btnUpdate.setOnAction(e -> updateMember());

        lblStatus = new Label();

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        gridPane.add(lblMemberID, 0, 0);
        gridPane.add(txtMemberID, 1, 0);
        gridPane.add(btnLoad, 2, 0);
        gridPane.add(lblFirstName, 0, 1);
        gridPane.add(txtFirstName, 1, 1);
        gridPane.add(lblLastName, 0, 2);
        gridPane.add(txtLastName, 1, 2);
        gridPane.add(lblPhone, 0, 3);
        gridPane.add(txtPhone, 1, 3);
        gridPane.add(lblEmail, 0, 4);
        gridPane.add(txtEmail, 1, 4);
        gridPane.add(lblJoinDate, 0, 5);
        gridPane.add(txtJoinDate, 1, 5);
        gridPane.add(lblSubscriptionPlan, 0, 6);
        gridPane.add(cbSubscriptionPlan, 1, 6);
        gridPane.add(btnUpdate, 1, 7);
        gridPane.add(lblStatus, 1, 8);

        primaryStage.setScene(new Scene(gridPane, 500, 400));
        primaryStage.show();
    }

    private void loadMember() {
        String memberID = txtMemberID.getText().trim();
        if (memberID.isEmpty()) {
            lblStatus.setText("Please enter a Member ID.");
            return;
        }

        String sql = "SELECT * FROM members LEFT JOIN subscriptions ON members.member_id = subscriptions.member_id WHERE members.member_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(memberID));
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                txtFirstName.setText(rs.getString("Firstname"));
                txtLastName.setText(rs.getString("Lastname"));
                txtPhone.setText(rs.getString("phone"));
                txtEmail.setText(rs.getString("email"));
                txtJoinDate.setText(rs.getString("join_date"));
                cbSubscriptionPlan.setValue(rs.getString("plan_name"));
                lblStatus.setText("Member loaded successfully.");
            } else {
                lblStatus.setText("Member not found.");
            }
        } catch (SQLException e) {
            lblStatus.setText("Error loading member.");
            e.printStackTrace();
        }
    }

    private void updateMember() {
        String memberID = txtMemberID.getText().trim();
        String firstName = txtFirstName.getText().trim();
        String lastName = txtLastName.getText().trim();
        String phone = txtPhone.getText().trim();
        String email = txtEmail.getText().trim();
        String joinDate = txtJoinDate.getText().trim();
        String subscriptionPlan = cbSubscriptionPlan.getValue();

        if (memberID.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty() || email.isEmpty() || joinDate.isEmpty() || subscriptionPlan == null) {
            lblStatus.setText("Please fill all fields.");
            return;
        }

        String updateMemberSQL = "UPDATE members SET Firstname = ?, Lastname = ?, phone = ?, email = ?, join_date = ? WHERE member_id = ?";
        String updateSubscriptionSQL = "INSERT INTO subscriptions (member_id, plan_name) VALUES (?, ?) ON DUPLICATE KEY UPDATE plan_name = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement memberStmt = conn.prepareStatement(updateMemberSQL);
             PreparedStatement subscriptionStmt = conn.prepareStatement(updateSubscriptionSQL)) {

            memberStmt.setString(1, firstName);
            memberStmt.setString(2, lastName);
            memberStmt.setString(3, phone);
            memberStmt.setString(4, email);
            memberStmt.setString(5, joinDate);
            memberStmt.setInt(6, Integer.parseInt(memberID));
            memberStmt.executeUpdate();

            subscriptionStmt.setInt(1, Integer.parseInt(memberID));
            subscriptionStmt.setString(2, subscriptionPlan);
            subscriptionStmt.setString(3, subscriptionPlan);
            subscriptionStmt.executeUpdate();

            lblStatus.setText("Member updated successfully.");
        } catch (SQLException e) {
            lblStatus.setText("Error updating member.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
