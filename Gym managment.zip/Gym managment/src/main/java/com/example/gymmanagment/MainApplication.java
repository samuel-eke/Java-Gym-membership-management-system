package com.example.gymmanagment;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainApplication extends Application {
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Gym Management System");

        Button btnAddMember = new Button("Add Member");
        btnAddMember.setOnAction(e -> new AddMemberUI().start(new Stage()));

        Button btnViewMembers = new Button("View Members");
        btnViewMembers.setOnAction(e -> new ViewMembersUI().start(new Stage()));

        Button btnManagePayments = new Button("Manage Payments");
        btnManagePayments.setOnAction(e -> new ManagePaymentsUI().start(new Stage()));

        Button btnManageSubscriptions = new Button("Manage Subscriptions");
        btnManageSubscriptions.setOnAction(e -> new UpdateSubscriptionUI().start(new Stage()));

        VBox layout = new VBox(10, btnAddMember, btnViewMembers, btnManagePayments, btnManageSubscriptions);
        layout.setPadding(new Insets(20));

        primaryStage.setScene(new Scene(layout, 400, 300));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
