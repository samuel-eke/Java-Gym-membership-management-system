module com.example.gymmanagment {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.gymmanagment to javafx.fxml;
    exports com.example.gymmanagment;
}